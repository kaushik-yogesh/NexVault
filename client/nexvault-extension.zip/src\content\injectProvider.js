/**
 * NexVault — Injected Provider (window.ethereum)
 * 
 * This script runs in the PAGE context (not extension context).
 * It provides EIP-1193 compatible window.ethereum object.
 */

(function () {
  'use strict';

  if (window.ethereum?.isNexVault) return; // Already injected

  let requestId = 0;
  const pendingRequests = new Map();
  const eventListeners = {};

  const provider = {
    isMetaMask: true, // Compatibility — many DApps check this
    isNexVault: true,
    selectedAddress: null,
    chainId: '0x1',
    networkVersion: '1',
    isConnected: () => true,

    /**
     * EIP-1193 request method
     */
    async request({ method, params = [] }) {
      return new Promise((resolve, reject) => {
        const id = ++requestId;

        pendingRequests.set(id, { resolve, reject });

        window.postMessage({
          target: 'nexvault-contentscript',
          id,
          method,
          params,
        }, '*');

        // Timeout after 30 seconds
        setTimeout(() => {
          if (pendingRequests.has(id)) {
            pendingRequests.delete(id);
            reject(new Error('Request timed out'));
          }
        }, 30000);
      });
    },

    /**
     * Legacy send method (deprecated but still used by some DApps)
     */
    send(methodOrPayload, callbackOrParams) {
      if (typeof methodOrPayload === 'string') {
        return provider.request({
          method: methodOrPayload,
          params: callbackOrParams || [],
        });
      }

      if (typeof callbackOrParams === 'function') {
        provider
          .request(methodOrPayload)
          .then((result) => callbackOrParams(null, { result }))
          .catch((error) => callbackOrParams(error));
        return;
      }

      return provider.request(methodOrPayload);
    },

    /**
     * Legacy sendAsync method
     */
    sendAsync(payload, callback) {
      provider
        .request(payload)
        .then((result) => callback(null, { id: payload.id, jsonrpc: '2.0', result }))
        .catch((error) => callback(error));
    },

    /**
     * Legacy enable method
     */
    enable() {
      return provider.request({ method: 'eth_requestAccounts' });
    },

    /**
     * Event listener methods
     */
    on(event, listener) {
      if (!eventListeners[event]) eventListeners[event] = [];
      eventListeners[event].push(listener);
      return provider;
    },

    removeListener(event, listener) {
      if (!eventListeners[event]) return provider;
      eventListeners[event] = eventListeners[event].filter((l) => l !== listener);
      return provider;
    },

    removeAllListeners(event) {
      if (event) {
        delete eventListeners[event];
      } else {
        Object.keys(eventListeners).forEach((e) => delete eventListeners[e]);
      }
      return provider;
    },
  };

  // Listen for responses from content script
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    if (event.data?.target !== 'nexvault-inpage') return;

    // Handle RPC responses
    if (event.data.id && pendingRequests.has(event.data.id)) {
      const { resolve, reject } = pendingRequests.get(event.data.id);
      pendingRequests.delete(event.data.id);

      if (event.data.error) {
        reject(new Error(event.data.error));
      } else {
        resolve(event.data.result);
      }
    }

    // Handle events
    if (event.data.event) {
      const listeners = eventListeners[event.data.event] || [];
      listeners.forEach((listener) => {
        try {
          listener(event.data.data);
        } catch (err) {
          console.error('[NexVault] Event listener error:', err);
        }
      });
    }
  });

  // Inject as window.ethereum
  try {
    Object.defineProperty(window, 'ethereum', {
      value: new Proxy(provider, {
        deleteProperty: () => true,
      }),
      writable: false,
      configurable: false,
    });

    // Announce provider (EIP-6963)
    window.dispatchEvent(new Event('ethereum#initialized'));
  } catch (err) {
    // If window.ethereum already exists, try to override
    window.ethereum = provider;
  }
})();
